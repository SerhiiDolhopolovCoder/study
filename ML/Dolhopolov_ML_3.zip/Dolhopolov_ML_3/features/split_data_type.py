from enum import Enum


class SplitDataType(Enum):
    TRAIN = "train"
    TEST = "test"